# POWERS-OF-2

## AIMA3e
__generator__ Powers-Of-2() __yields__ ints  
&emsp;_i_ &larr; 1  
&emsp;__while__ _true_ __do__  
&emsp;&emsp;__yield__ _i_  
&emsp;&emsp;_i_ &larr; 2 x _i_  

---
__for__ _p_ __in__ Powers-Of-2() __do__  
&emsp;PRINT(_p_)  

---
__Figure ??__ Example of a generator function and its invocation within a loop.
