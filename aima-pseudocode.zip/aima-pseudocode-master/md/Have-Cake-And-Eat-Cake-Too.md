# HAVE-CAKE-AND-EAT-CAKE-TOO-PROBLEM

## AIMA3e
_Init_(_Have_(_Cake_))  
_Goal_(_Have_(_Cake_) &and; _Eaten_(_Cake_))  
_Action_(_Eat_(_Cake_)  
&emsp;PRECOND: _Have_(_Cake_)  
&emsp;EFFECT: &not; _Have_(_Cake_) &and; _Eaten_(_Cake_))  
_Action_(_Bake_(_Cake_)  
&emsp;PRECOND: &not; _Have_(_Cake_)  
&emsp;EFFECT: _Have_(_Cake_))

---
__Figure ??__ The "have cake and eat cake too" problem.
